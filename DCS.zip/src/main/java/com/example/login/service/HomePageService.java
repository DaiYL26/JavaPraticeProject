package com.example.login.service;

import com.example.login.vo.Result;

public interface HomePageService {

//    Result getLearnPlan(Long userid);
//
//    Result getPlanStatus(Long userid);

    Result getHomePageData(Long userid);

}
